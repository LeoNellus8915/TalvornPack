#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
flat in vec4 miniData;
in vec2 miniLocal;

out vec4 fragColor;

// stessa funzione di hash e di rumore di UberTerrain (aritmetica a 32 bit con segno ignorato)
uint hashCell(int x, int y, int seed) {
    uint v = uint(x) * 73856093u ^ uint(y) * 19349663u ^ uint(seed) * 83492791u;
    v ^= v >> 13;
    v *= 0x5BD1E995u;
    v ^= v >> 15;
    return v & 0x7FFFFFFFu;
}

float valueNoise(float x, float y, int seed) {
    float fx0 = floor(x);
    float fy0 = floor(y);
    int x0 = int(fx0);
    int y0 = int(fy0);
    float fx = x - fx0;
    float fy = y - fy0;
    fx = fx * fx * (3.0 - 2.0 * fx);
    fy = fy * fy * (3.0 - 2.0 * fy);
    float a = float(hashCell(x0, y0, seed) & 1023u) / 1023.0;
    float b = float(hashCell(x0 + 1, y0, seed) & 1023u) / 1023.0;
    float c = float(hashCell(x0, y0 + 1, seed) & 1023u) / 1023.0;
    float d = float(hashCell(x0 + 1, y0 + 1, seed) & 1023u) / 1023.0;
    return (a * (1.0 - fx) + b * fx) * (1.0 - fy) + (c * (1.0 - fx) + d * fx) * fy;
}

// la variante dei biomi dell'U3 sposta il punto in cui si campiona il rumore (stesse formule di UberTerrain.offsetX/Z)
vec2 variantOffset(int v) {
    return vec2(float((v * 7919 + 1013) % 5003 - 2501), float((v * 6733 + 389) % 5009 - 2504));
}

float regionValue(float x, float z, vec2 o) {
    float v = valueNoise((x + o.x) / 600.0, (z + o.y) / 600.0, 77) * 0.65 + valueNoise((x + o.x) / 230.0, (z + o.y) / 230.0, 91) * 0.35;
    return v;
}

float snowValue(float x, float z, vec2 o) {
    float v = valueNoise((x + o.x) / 520.0, (z + o.y) / 520.0, 133) * 0.65 + valueNoise((x + o.x) / 210.0, (z + o.y) / 210.0, 157) * 0.35;
    return v;
}

void main() {
    vec4 color = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
    if (miniData.w > 0.5) {
        // pixel (4 blocchi) del terreno; il centro dell'area (32, 32) è il giocatore
        // fase di mezza cella (3 blocchi) dall alpha della texture dello sfondo: 255, 251, 247, 243 = x + 2 z
        float alpha255 = texture(Sampler0, texCoord0).a * 255.0;
        int phase = int(floor((255.0 - alpha255) / 4.0 + 0.5));
        int setB = (phase >> 2) & 1; // U6: il codice del mondo e nel secondo gruppo di sfondi
        phase = phase & 3;
        float sc = (miniData.z > 1.5 && miniData.z < 2.5) ? 3.0 : 6.0; // blocchi per pixel: la lobby e zoomata
        float wx = miniData.x + float(phase & 1) * sc * 0.5 + (miniLocal.x - 32.0) * sc;
        float wz = miniData.y + float((phase >> 1) & 1) * sc * 0.5 + (miniLocal.y - 32.0) * sc;
        int gx = int(floor(wx / sc));
        int gz = int(floor(wz / sc));
        float grain = float(hashCell(gx, gz, 5) % 100u) / 99.0;
        float tone = 1.0 + (float(hashCell(gx, gz, 3) % 9u) - 4.0) * 0.022;
        int slot = int(miniData.z + 0.5) - 3 + 48 * setB;
        int u7Slot = slot - 58; // U7: slot 10-19 del secondo gruppo
        bool u7 = setB == 1 && u7Slot >= 0 && u7Slot < 10;
        vec2 variantShift = miniData.z > 2.5 ? variantOffset(u7 ? u7Slot : slot % 12) : vec2(0.0);
        bool snowRegion = miniData.z > 2.5 && slot >= 12 && snowValue(wx, wz, variantShift) > 0.55;
        bool snow = snowRegion && setB == 0;
        bool jungle = snowRegion && setB == 1; // U6: la regione della neve e la giungla fungina
        bool desert = miniData.z > 0.5 && !snowRegion && regionValue(wx, wz, variantShift) > 0.52;
        bool city = u7 && !snowRegion && !desert; // U7: la regione rimanente e la Neon City
        bool candy = slot >= 24 && !snowRegion && !desert && !u7;
        bool volcano = slot >= 36 && desert; // U5 (slot 36-45): la regione del deserto e il vulcano
        vec3 rgb;
        if (miniData.z > 1.5 && miniData.z < 2.5) {
            // lobby: solo erba e mura di quarzo (stesse misure di LobbyLayout)
            float ax = abs(wx);
            float az = abs(wz);
            rgb = mix(vec3(90.0, 148.0, 54.0), vec3(125.0, 180.0, 74.0), 0.3 + grain * 0.35) * tone;
            if (ax > 250.0 || az > 250.0) {
                rgb = vec3(46.0, 54.0, 92.0);
            } else if (ax >= 247.0 || az >= 247.0) {
                rgb = vec3(238.0, 238.0, 252.0);
            }
            // niente piazza, viale o piazzale: lo spawn e' il simbolo del castello (glifo, vedi Hud.minimap)
        } else if (snow) {
            rgb = mix(vec3(222.0, 236.0, 252.0), vec3(255.0, 255.0, 255.0), 0.25 + grain * 0.6) * tone;
            if (hashCell(gx, gz, 17) % 47u == 0u) {
                rgb = vec3(150.0, 205.0, 245.0); // ghiaccio
            }
        } else if (jungle) {
            rgb = mix(vec3(34.0, 92.0, 78.0), vec3(70.0, 140.0, 112.0), 0.25 + grain * 0.55) * tone;
            if (hashCell(gx, gz, 19) % 29u == 0u) {
                rgb = vec3(124.0, 240.0, 216.0); // spore luminose
            } else if (hashCell(gx, gz, 43) % 53u == 0u) {
                rgb = vec3(224.0, 98.0, 159.0); // cappello di fungo
            }
        } else if (volcano) {
            rgb = mix(vec3(42.0, 36.0, 56.0), vec3(78.0, 66.0, 102.0), 0.25 + grain * 0.55) * tone;
            if (hashCell(gx, gz, 13) % 37u == 0u) {
                rgb = vec3(255.0, 122.0, 26.0); // magma
            } else if (hashCell(gx, gz, 41) % 71u == 0u) {
                rgb = vec3(235.0, 219.0, 176.0); // ossa
            }
        } else if (desert) {
            rgb = mix(vec3(233.0, 194.0, 90.0), vec3(246.0, 220.0, 136.0), 0.25 + grain * 0.5);
            if (hashCell(gx, gz, 13) % 53u == 0u) {
                rgb *= 0.8;
            }
        } else if (city) {
            rgb = mix(vec3(28.0, 32.0, 64.0), vec3(48.0, 56.0, 108.0), 0.25 + grain * 0.55) * tone;
            if ((gx & 15) == 0 || (gz & 15) == 0) {
                rgb = vec3(70.0, 80.0, 140.0); // strade
            }
            if (hashCell(gx, gz, 31) % 41u == 0u) {
                rgb = vec3(53.0, 240.0, 255.0); // neon ciano
            } else if (hashCell(gx, gz, 47) % 53u == 0u) {
                rgb = vec3(255.0, 60.0, 200.0); // neon magenta
            }
        } else if (candy) {
            rgb = mix(vec3(255.0, 142.0, 200.0), vec3(255.0, 200.0, 230.0), 0.25 + grain * 0.55) * tone;
            if (hashCell(gx, gz, 23) % 31u == 0u) {
                rgb = vec3(255.0, 240.0, 120.0); // codetta
            } else if (hashCell(gx, gz, 29) % 43u == 0u) {
                rgb = vec3(120.0, 220.0, 255.0);
            }
        } else {
            rgb = mix(vec3(90.0, 148.0, 54.0), vec3(125.0, 180.0, 74.0), 0.3 + grain * 0.35) * tone;
            if (hashCell(gx, gz, 11) % 61u == 0u) {
                rgb *= 0.8;
            }
        }
        color = vec4(rgb / 255.0, 1.0);
    }
    if (color.a < 0.1) {
        discard;
    }
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
