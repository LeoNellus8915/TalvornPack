#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
flat out vec4 miniData;
out vec2 miniLocal;

void main() {
    vec3 pos = Position;
    miniData = vec4(0.0);
    miniLocal = vec2(0.0);
    vec4 tint = Color * texelFetch(Sampler2, UV2 / 16, 0);
    bool gui = ProjMat[3][3] == 1.0;
    ivec3 rgb = ivec3(round(Color.rgb * 255.0));
    bool white = gui && rgb == ivec3(78, 92, 36);
    bool gold = gui && rgb == ivec3(78, 92, 37);
    bool shadow = gui && all(lessThanEqual(abs(rgb - ivec3(19, 23, 9)), ivec3(1)));

    bool compass = gui && rgb == ivec3(86, 100, 44);
    bool compassShadow = gui && all(lessThanEqual(abs(rgb - ivec3(21, 25, 11)), ivec3(1)));
    bool mini = gui && rgb == ivec3(94, 108, 52);
    bool miniShadow = gui && all(lessThanEqual(abs(rgb - ivec3(23, 27, 13)), ivec3(1)));
    if (mini || miniShadow) {
        // minimappa: in alto a destra (x dal bordo destro, meno il margine), y come l'angolo
        float mwidth = 2.0 / ProjMat[0][0];
        float mheight = -2.0 / ProjMat[1][1];
        pos.x = Position.x + mwidth * 0.5 - 10.0;
        pos.y = Position.y - (mheight - 65.0);
        tint = mini ? vec4(1.0, 1.0, 1.0, Color.a) : vec4(0.0);
    }
    if (compass || compassShadow) {
        // bussola: in alto al centro (x invariata), la y è relativa al bordo alto come per l'angolo
        float cheight = -2.0 / ProjMat[1][1];
        pos.y = Position.y - (cheight - 65.0);
        tint = compass ? vec4(1.0, 1.0, 1.0, Color.a) : vec4(0.0);
    }
    // colonna dei blocchi della modalita laser: in basso a destra; il colore (110, 124, 68 + riga) porta la riga (0 = in basso),
    // ogni riga sta PITCH px piu in alto (= LaserArt.PITCH). L'ombra del testo (colore / 4) e nascosta
    bool laserCol = gui && rgb.r == 110 && rgb.g == 124 && rgb.b >= 68 && rgb.b <= 76;
    bool laserShadow = gui && rgb.r >= 26 && rgb.r <= 28 && rgb.g >= 30 && rgb.g <= 32 && rgb.b >= 16 && rgb.b <= 20;
    if (laserCol || laserShadow) {
        float lwidth = 2.0 / ProjMat[0][0];
        pos.x = Position.x + lwidth * 0.5 - 10.0;
        pos.y = Position.y - float(laserCol ? rgb.b - 68 : (rgb.b - 17) * 4) * 22.0;
        tint = laserCol ? vec4(1.0, 1.0, 1.0, Color.a) : vec4(0.0);
    }

    if (white || gold || shadow) {
        float width = 2.0 / ProjMat[0][0];
        float height = -2.0 / ProjMat[1][1];
        pos.x = Position.x - width * 0.5 + 10.0;
        pos.y = Position.y - (height - 65.0);
        if (white) {
            tint = vec4(1.0, 1.0, 1.0, Color.a);
        } else if (gold) {
            tint = vec4(1.0, 0.84, 0.36, Color.a);
        } else {
            tint = vec4(0.0, 0.0, 0.0, Color.a * 0.6);
        }
    }

    // sfondo della minimappa: il colore del testo porta la posizione del giocatore (4 bit di tipo 14 =
    // pianura+deserto o 13 = solo pianura, poi X e Z in celle da 4 blocchi, 10 bit ciascuno); il fragment
    // shader disegna il terreno vero (erba/sabbia) pixel per pixel. L'ombra del testo è nascosta.
    int kind = rgb.r >> 4;
    if (gui && kind >= 12 && kind <= 14 && !(rgb.r == rgb.g && rgb.g == rgb.b)) {
        float mw = 2.0 / ProjMat[0][0];
        float mh = -2.0 / ProjMat[1][1];
        int cx = ((rgb.r & 15) << 6) | (rgb.g >> 2);
        int cz = ((rgb.g & 3) << 8) | rgb.b;
        // codice del mondo: fascia x (0-3) e fascia z (0-3) da 256 celle e tipo 12-14; lobby = (2,1,13), U1 = (1,1,13),
        // le altre 24 combinazioni sono le varianti dei biomi dell'U3 (stesso ordine di Hud.minimap)
        int xs = min(cx / 256, 3);
        int zs = min(cz / 256, 3);
        int idx = (xs * 4 + zs) * 3 + (kind - 12);
        float code;
        if (idx == 28) {
            code = 2.0;
        } else if (idx == 16) {
            code = 0.0;
        } else {
            int variantIndex = idx;
            if (idx > 28) {
                variantIndex--;
            }
            if (idx > 16) {
                variantIndex--;
            }
            code = 3.0 + float(variantIndex);
        }
        float blocks = code == 2.0 ? 3.0 : 6.0; // la lobby e zoomata (3 blocchi per pixel)
        miniData = vec4(float(cx - (128 + 256 * xs)) * blocks, float(cz - (128 + 256 * zs)) * blocks, code, 1.0);
        miniLocal = vec2(Position.x - mw * 0.5 + 68.0, Position.y - (mh - 65.0) - 14.0);
        pos.x = Position.x + mw * 0.5 - 10.0;
        pos.y = Position.y - (mh - 65.0);
        tint = vec4(1.0, 1.0, 1.0, Color.a);
    } else if (gui && rgb.r >= 48 && rgb.r <= 59 && !(rgb.r == rgb.g && rgb.g == rgb.b)) {
        tint = vec4(0.0); // ombra del testo che porta la posizione (colore diviso per 4)
    }

    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = tint;
    texCoord0 = UV0;
}
