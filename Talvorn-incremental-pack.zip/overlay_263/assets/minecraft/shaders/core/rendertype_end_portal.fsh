#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:fog.glsl>
#include <minecraft:matrix.glsl>
#include <minecraft:globals.glsl>

uniform sampler2D Sampler0;
uniform sampler2D Sampler1;

layout(location = 0) in vec4 texProj0;
layout(location = 1) in float sphericalVertexDistance;
layout(location = 2) in float cylindricalVertexDistance;

const vec3[] COLORS = vec3[](
    vec3(0.036570, 0.014628, 0.103615),
    vec3(0.038408, 0.014350, 0.092854),
    vec3(0.047875, 0.017002, 0.101791),
    vec3(0.062150, 0.021222, 0.118742),
    vec3(0.071983, 0.023822, 0.125582),
    vec3(0.084327, 0.027202, 0.136011),
    vec3(0.127381, 0.039532, 0.177527),
    vec3(0.130879, 0.039331, 0.159360),
    vec3(0.182074, 0.053248, 0.195386),
    vec3(0.190300, 0.054371, 0.181238),
    vec3(0.163440, 0.045763, 0.138924),
    vec3(0.267665, 0.101713, 0.198072),
    vec3(0.236166, 0.113359, 0.148784),
    vec3(0.354167, 0.205417, 0.184167),
    vec3(0.429011, 0.291727, 0.175895),
    vec3(0.727640, 0.566468, 0.219493)
);

const mat4 SCALE_TRANSLATE = mat4(
    0.5, 0.0, 0.0, 0.25,
    0.0, 0.5, 0.0, 0.25,
    0.0, 0.0, 1.0, 0.0,
    0.0, 0.0, 0.0, 1.0
);

mat4 end_portal_layer(float layer) {
    mat4 translate = mat4(
        1.0, 0.0, 0.0, 17.0 / layer,
        0.0, 1.0, 0.0, (2.0 + layer / 1.5) * (GameTime * 1.5),
        0.0, 0.0, 1.0, 0.0,
        0.0, 0.0, 0.0, 1.0
    );

    mat2 rotate = mat2_rotate_z(radians((layer * layer * 4321.0 + layer * 9.0) * 2.0));

    mat2 scale = mat2((4.5 - layer / 4.0) * 2.0);

    return mat4(scale * rotate) * translate * SCALE_TRANSLATE;
}

layout(location = 0) out vec4 fragColor;

void main() {
    vec3 color = textureProj(Sampler0, texProj0).rgb * COLORS[0];
    for (int i = 0; i < PORTAL_LAYERS; i++) {
        color += textureProj(Sampler1, texProj0 * end_portal_layer(float(i + 1))).rgb * COLORS[i];
    }
    fragColor = apply_fog(vec4(color, 1.0), sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
